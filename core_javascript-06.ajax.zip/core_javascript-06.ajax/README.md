

## 멋쟁이 사자처럼
---
### 비동기 통신에 대해 학습합니다.

---



- XHMHttpRequest
- fetch API











